# projectParams.py
# ----------------

STUDENT_CODE_DEFAULT = 'analysis.py,qlearningAgents.py,valueIterationAgents.py'
PROJECT_TEST_CLASSES = 'reinforcementTestClasses.py'
PROJECT_NAME = 'Project 3: Reinforcement learning'
